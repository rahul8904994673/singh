package com.itt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IttSeatAllocApplication {

	public static void main(String[] args) {
		SpringApplication.run(IttSeatAllocApplication.class, args);
	}

}
