package com.itt.config;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import com.itt.entity.Empdtls;
import com.itt.repository.Emprepo;

public class EmpDetailsServiceImpl implements UserDetailsService{

	@Autowired
	private Emprepo emprepo;
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
	
	Empdtls 	emp=emprepo.findByEmail(username);
		
		if(emp==null)
		{
			throw new UsernameNotFoundException("User Not Exist");
		}
		else {
			CustomEmpDetails customempdetails =new CustomEmpDetails(emp);
			return customempdetails;
		}
		
		
	}

}
