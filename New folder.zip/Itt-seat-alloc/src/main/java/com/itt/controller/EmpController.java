package com.itt.controller;

import java.security.Principal;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.itt.Service.Dao;
import com.itt.Service.EmployeeService;
import com.itt.Service.EmployeeServiceImpl;
import com.itt.dto.Floor;
import com.itt.entity.Empdtls;
import com.itt.entity.Employee;
import com.itt.entity.FloorSelected;
import com.itt.entity.SeatDeatils;
import com.itt.entity.Location;
import com.itt.repository.Emprepo;


@Controller
@RequestMapping("/user")
public class EmpController {
	
	@Autowired
	private Emprepo emprepo;
	
@Autowired
private Dao dao;
	
	@Autowired
	private EmployeeService employeeService;
	
	@Autowired
	private EmployeeServiceImpl employeeServiceImpl;

	
	
	public void addCommonData(Principal p,Model m)
	{
		String email=p.getName();
		Empdtls user=emprepo.findByEmail(email);
		m.addAttribute("user",user);
		
	}
	
	/*
	 * @GetMapping("/home") public String home() { return "user/home"; }
	 */

	@GetMapping("/index")
	public String index(Model m,HttpSession session)
	{
		String location=(String) session.getAttribute("locationName");
		System.out.print(location+"lol");
		List<Location> location1=dao.getAllLocation();
		m.addAttribute("locationlist", location1);
		System.out.println(location1+"loll12");
		
		return "user/index";
	}
	
	@GetMapping("/raiserequest")
	public String home()
	{
		System.out.print("raiserequest api ");
		return "user/raiserequest";
	}
	
	@GetMapping("/home")
	public String book(@RequestParam(name = "locationName") String location, HttpSession session)
	{
		
		System.out.println("home api "+location);
		session.setAttribute("locationName", location);
		return "user/home";
	}
	
	/*
	 * @GetMapping("/viewrequest") public String view() {System.out.print("hello2");
	 * 
	 * return "user/viewrequest"; }
	 */
	
	@PostMapping("/saveEmployee")
	public String saveEmployee(@ModelAttribute Employee employee,HttpSession session) {
		// save employee to database
		/* employee.setEmpdtls(u); */
		System.out.println("hello");
		System.out.println(employee);
		employeeService.saveEmployee(employee);
		/* return "redirect:/user:raiserequest"; */
		return "user/home";
	}
	
	@GetMapping("/viewrequest")
	public String viewraisedRequest(Model m)
	{
		System.out.print("viewReruest");
		m.addAttribute("listEmployee",employeeService.getallEmplyees());
		return "user/viewrequest";
	}
	
	@PostMapping("/check")
	public String CheckSeat(Model m, HttpSession session)
	{
		
		System.out.println("##########################");
//		Employee object=(Employee)session.getAttribute("user");
		
		
		
		String location=(String) session.getAttribute("locationName");
		System.out.println("########################## print floors "+session.getAttribute("floor_name"));
//		if(location.equals(null))
//		{
//			return "home";
//		}
		System.out.println("##########################Before service call ");
		List<Floor> floors = employeeServiceImpl.getFloorDetail(location);
		
		m.addAttribute("floors", floors);
		return "user/TableView";
		
		
	}
	

	

	}
	



