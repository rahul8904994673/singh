package com.itt.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.itt.entity.Empdtls;
import com.itt.repository.Emprepo;

@Controller
public class HomeController {
	
	@Autowired
	private Emprepo emprepo;
	
	@Autowired
	private BCryptPasswordEncoder bcrypt;
	
	@GetMapping("/")
	public String home()
	{
		return "home";
	}

	@GetMapping("/login")
	public String login()
	{
		return "login";
	}
	@GetMapping("/signup")
	public String signup()
	{
		return "signup";
	}
	
	@PostMapping("/saveEmp")
	public String saveEmployee(@ModelAttribute Empdtls emp,Model m,HttpSession session)
	{
		emp.setPassword(bcrypt.encode(emp.getPassword()));
		
		emp.setRole("ROLE_USER");
		
	Empdtls	e=emprepo.save(emp);
	
	if(e!=null)
	{
		session.setAttribute("msg", "Registration Successful");	
	}
	else
	{
		session.setAttribute("msg", "Error Occured");		
	}
	
		
		return "redirect:/signup";
	}

}
