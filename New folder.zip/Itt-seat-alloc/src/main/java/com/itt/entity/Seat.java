package com.itt.entity;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="seat")
public class Seat {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int seatNumber;
	
	private boolean isAvailable;
	
	@ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "fid")
	private FloorSelected floorSelected ;

	public int getSeatNumber() {
		return seatNumber;
	}

	public void setSeatNumber(int seatNumber) {
		this.seatNumber = seatNumber;
	}

	public boolean isAvailable() {
		return isAvailable;
	}

	public void setAvailable(boolean isAvailable) {
		this.isAvailable = isAvailable;
	}

	public FloorSelected getFloorSelected() {
		return floorSelected;
	}

	public void setFloorSelected(FloorSelected floorSelected) {
		this.floorSelected = floorSelected;
	}

	@Override
	public String toString() {
		return "Seat [seatNumber=" + seatNumber + ", isAvailable=" + isAvailable + ", floorSelected=" + floorSelected
				+ "]";
	}
	
	
}
