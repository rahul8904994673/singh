package com.itt.entity;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import lombok.Data;

@Data
@Entity
@Table(name = "employee")
public class Employee {
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id1;
	
	@Column(name = "eid")
	private String eid;
	
	@Column(name = "floor")
	private String floor;
	
	@Column(name = "seatno")
	private String seatno;
	
	private String name;
	
	private String depatment;
	
	@OneToMany(mappedBy = "employee",fetch=FetchType.EAGER)
	private List<SeatDeatils> seat;

	public Employee(int id1, String eid, String floor, String seatno, String name, String depatment,
			List<SeatDeatils> seat) {
		super();
		this.id1 = id1;
		this.eid = eid;
		this.floor = floor;
		this.seatno = seatno;
		this.name = name;
		this.depatment = depatment;
		this.seat = seat;
	}

	public int getId1() {
		return id1;
	}

	public void setId1(int id1) {
		this.id1 = id1;
	}

	public String getEid() {
		return eid;
	}

	public void setEid(String eid) {
		this.eid = eid;
	}

	public String getFloor() {
		return floor;
	}

	public void setFloor(String floor) {
		this.floor = floor;
	}

	public String getSeatno() {
		return seatno;
	}

	public void setSeatno(String seatno) {
		this.seatno = seatno;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDepatment() {
		return depatment;
	}

	public void setDepatment(String depatment) {
		this.depatment = depatment;
	}

	public List<SeatDeatils> getSeat() {
		return seat;
	}

	public void setSeat(List<SeatDeatils> seat) {
		this.seat = seat;
	}

	@Override
	public String toString() {
		return "Employee [id1=" + id1 + ", eid=" + eid + ", floor=" + floor + ", seatno=" + seatno + ", name=" + name
				+ ", depatment=" + depatment + ", seat=" + seat + "]";
	}
	
	public Employee()
	{
		super();
	}



	

	

}
