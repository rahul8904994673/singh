package com.itt.entity;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="floorSelected")
public class FloorSelected {
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long fid;
	
	@Column(name="floor")
	private int floor;
	
	
	@ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "location_id")
	private Location location;
	
	@OneToMany(mappedBy = "floorSelected", fetch = FetchType.LAZY)
	private List<Seat> seat;
	
	private long no_of_seat;
	
	private long total_seat;
	
	

	
	
	@Override
	public String toString() {
		return "FloorSelected [fid=" + fid + ", floor=" + floor + ", location=" + location + ", no_of_seat="
				+ no_of_seat + ", total_seat=" + total_seat + "]";
	}





	public FloorSelected(long fid, int floor, Location location, long no_of_seat, long total_seat) {
		super();
		this.fid = fid;
		this.floor = floor;
		this.location = location;
		this.no_of_seat = no_of_seat;
		this.total_seat = total_seat;
	}





	public long getFid() {
		return fid;
	}





	public void setFid(long fid) {
		this.fid = fid;
	}





	public int getFloor() {
		return floor;
	}





	public void setFloor(int floor) {
		this.floor = floor;
	}





	public Location getLocation() {
		return location;
	}





	public void setLocation(Location location) {
		this.location = location;
	}





	public long getNo_of_seat() {
		return no_of_seat;
	}





	public void setNo_of_seat(long no_of_seat) {
		this.no_of_seat = no_of_seat;
	}





	public long getTotal_seat() {
		return total_seat;
	}





	public void setTotal_seat(long total_seat) {
		this.total_seat = total_seat;
	}





	public FloorSelected()
	{
		super();
	}

}
