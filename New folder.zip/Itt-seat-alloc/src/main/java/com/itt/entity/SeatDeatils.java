package com.itt.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class SeatDeatils {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "s_id")
	private long sId;
	@ElementCollection
	private List<String> seatNo;
	private int empid;
	private String name;
	private String department;
    
	@ManyToOne
	private Empdtls employee;
	
	@ManyToOne(cascade=CascadeType.ALL,fetch=FetchType.EAGER)
	private FloorSelected operation;
	
	
	
public SeatDeatils(long sId, List<String> seatNo, int empid, String name, String department, Empdtls employee,
			FloorSelected operation) {
		super();
		this.sId = sId;
		this.seatNo = seatNo;
		this.empid = empid;
		this.name = name;
		this.department = department;
		this.employee = employee;
		this.operation = operation;
	}



public long getsId() {
	return sId;
}



public void setsId(long sId) {
	this.sId = sId;
}



public List<String> getSeatNo() {
	return seatNo;
}



public void setSeatNo(List<String> seatNo) {
	this.seatNo = seatNo;
}



public int getEmpid() {
	return empid;
}



public void setEmpid(int empid) {
	this.empid = empid;
}



public String getName() {
	return name;
}



public void setName(String name) {
	this.name = name;
}



public String getDepartment() {
	return department;
}



public void setDepartment(String department) {
	this.department = department;
}



public Empdtls getEmployee() {
	return employee;
}



public void setEmployee(Empdtls employee) {
	this.employee = employee;
}



public FloorSelected getOperation() {
	return operation;
}



public void setOperation(FloorSelected operation) {
	this.operation = operation;
}




@Override
public String toString() {
	return "SeatDeatils [sId=" + sId + ", seatNo=" + seatNo + ", empid=" + empid + ", name=" + name + ", department="
			+ department + ", employee=" + employee + ", operation=" + operation + "]";
}



public SeatDeatils()
{
	super();
	
}


	
	
}
