package com.itt.entity;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="location_id")
public class Location {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long id2;
	
	@Column(nullable = false)
	private String locationName;
	
	@Column(nullable = false)
	private String imgName;

	
	@OneToMany(mappedBy = "location", fetch = FetchType.LAZY)
	private List<FloorSelected> floorSelected;
	
	
	public Location(long id2, String locationName, String imgName) {
		super();
		this.id2 = id2;
		this.locationName = locationName;
		this.imgName = imgName;
	}

	public long getId2() {
		return id2;
	}

	public void setId2(long id2) {
		this.id2 = id2;
	}

	public String getLocationName() {
		return locationName;
	}

	public void setLocationName(String locationName) {
		this.locationName = locationName;
	}

	public String getImgName() {
		return imgName;
	}

	public void setImgName(String imgName) {
		this.imgName = imgName;
	}

	@Override
	public String toString() {
		return "location [id2=" + id2 + ", locationName=" + locationName + ", imgName=" + imgName + "]";
	}

public Location() {
	super();
}
	
	
	

}
