package com.itt.Service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itt.dto.Floor;
import com.itt.entity.Employee;
import com.itt.entity.FloorSelected;
import com.itt.entity.Location;
import com.itt.entity.Seat;
import com.itt.repository.EmployeeRepository;
import com.itt.repository.FloorRepository;
import com.itt.repository.LocationRepo;
import com.itt.repository.SeatRepository;

@Service
public class EmployeeServiceImpl implements EmployeeService{

	@Autowired
	private EmployeeRepository employeeRepository;
	
	
	@Autowired
	private FloorRepository floorSelected;
	
	
	@Autowired
	private SeatRepository seatRepo;
	
	@Autowired
	private LocationRepo locatioRepo;

	@Override
	public void saveEmployee(Employee employee) {
	employeeRepository.save(employee);
		
	}

	@Override
	public List<Employee> getallEmplyees() {
		
		return employeeRepository.findAll();
		
	}
	
	public List<Floor> getFloorDetail(String locatioName){
		Location location = locatioRepo.findByLocationName(locatioName);
		System.out.println("#################################################################### "+locatioName);
		System.out.println(location.toString());
		List<FloorSelected> floors = floorSelected.findAllByLocation(location);
		
		System.out.println("#################################################################### "+locatioName);
		List<Floor> floorsOut = new ArrayList<>();
		for(FloorSelected floor : floors) {
			Floor floorOut = new Floor();
			floorOut.setLocation(locatioName);
			floorOut.setFloor(floor.getFloor());
			floorOut.setNo_of_seat(floor.getNo_of_seat());
			floorOut.setTotal_seat(floor.getTotal_seat());
			floorsOut.add(floorOut);
			System.out.println(floorsOut.toString());
			//if(floor.getFloor()==)
			List<Seat> seat = seatRepo.findAllByFloorSelected(floor.getFid());
			System.out.println("####################################################################Seat aVailablity "+seat.toString());
		}
		
		return floorsOut;
	}

	




}
