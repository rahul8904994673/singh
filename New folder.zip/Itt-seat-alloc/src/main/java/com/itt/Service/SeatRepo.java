package com.itt.Service;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.itt.entity.SeatDeatils;

public interface SeatRepo extends JpaRepository<SeatDeatils, Long>{
	
	@Query(value="select * from SeatDetails where employee_eid=?", nativeQuery = true)
	public List<SeatDeatils> getAllSeat(long id);
	
	@Query(value="select * from SeatDetails inner join SeatDetails_seat_no on "
			+"SeatDetails_sid=SeatDetails_seat_no.SeatDetails_sid inner join SeatDetails.operation_fid=floorSelected.fid"
			+"where floor=?",nativeQuery = true)
	public List<SeatDeatils> getAllbyfloor(String floor);

}
 