package com.itt.Service;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.itt.entity.SeatDeatils;
import com.itt.repository.LocationRepo;
import com.itt.entity.Location;

@Component
public class Dao {
	
	@Autowired
	private LocationRepo lrepo;
	
	public List<Location> getAllLocation()
	{
		List<Location> list=this.lrepo.findAll();
		return list;
	}
	
	@Autowired
	SeatRepo seatrepo;
	
	public List<SeatDeatils> getAllSeat(String location)
	{
		List<SeatDeatils> list=seatrepo.getAllbyfloor(location);
		return list;
	}

}
