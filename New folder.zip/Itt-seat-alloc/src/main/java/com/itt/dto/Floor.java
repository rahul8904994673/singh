package com.itt.dto;

import javax.persistence.Column;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.itt.entity.Location;

public class Floor {

	
	private int floor;

	private String location;
	
	private long no_of_seat;
	
	private long total_seat;

	public int getFloor() {
		return floor;
	}

	public void setFloor(int floor) {
		this.floor = floor;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public long getNo_of_seat() {
		return no_of_seat;
	}

	public void setNo_of_seat(long no_of_seat) {
		this.no_of_seat = no_of_seat;
	}

	public long getTotal_seat() {
		return total_seat;
	}

	public void setTotal_seat(long total_seat) {
		this.total_seat = total_seat;
	}

	@Override
	public String toString() {
		return "Floor [floor=" + floor + ", location=" + location + ", no_of_seat=" + no_of_seat + ", total_seat="
				+ total_seat + "]";
	}
	

}
