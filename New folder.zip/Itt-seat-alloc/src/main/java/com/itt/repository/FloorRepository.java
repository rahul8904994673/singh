package com.itt.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.itt.entity.FloorSelected;
import com.itt.entity.Location;

@Repository
public interface FloorRepository  extends JpaRepository<FloorSelected, Long> {

	public List<FloorSelected> findAllByLocation(Location id);
}
