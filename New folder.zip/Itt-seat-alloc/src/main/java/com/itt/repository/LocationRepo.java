package com.itt.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.itt.entity.Empdtls;
import com.itt.entity.Employee;
import com.itt.entity.Location;

@Repository
public interface LocationRepo  extends JpaRepository<Location, Long> {

	public Location findByLocationName(String locationName);
}
