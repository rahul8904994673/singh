package com.itt.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.itt.entity.Empdtls;

public interface Emprepo extends JpaRepository<Empdtls, Integer>{

	public Empdtls findByEmail(String email);
	
}
